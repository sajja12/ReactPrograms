import React from 'react'
function Welcome(){
    return <h1>Welcome</h1>
}

export default Welcome