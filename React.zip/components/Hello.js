import React from 'react'

const Hello = () =>{
    // return(
    //     <div>
    //         <h1>Hello Lavanya</h1>
    //     </div>
    // )
    return React.createElement('div',null,'<h1>Hello Lavanya</h1>')
}

export default Hello